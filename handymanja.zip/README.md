# HandyManJa MVP

Jamaica’s On-Demand Workforce & Property Services Network.

## Tech Stack
- **Frontend**: React (Vite), Tailwind CSS, Framer Motion
- **Backend**: Express.js (Full-stack mode)
- **Database**: Supabase
- **Email**: Resend
- **Validation**: Zod + React Hook Form

## Setup Instructions

1. **Environment Variables**:
   Create a `.env` file based on `.env.example` and add your keys:
   - `VITE_SUPABASE_URL`
   - `VITE_SUPABASE_ANON_KEY`
   - `SUPABASE_SERVICE_ROLE_KEY`
   - `RESEND_API_KEY`

2. **Database Setup**:
   Run the SQL in `supabase_schema.sql` in your Supabase SQL Editor.

3. **Install Dependencies**:
   ```bash
   npm install
   ```

4. **Run Development Server**:
   ```bash
   npm run dev
   ```

## Deployment

This app is ready for Google Cloud Run.
1. Build the Docker image: `docker build -t handymanja .`
2. Push to Artifact Registry.
3. Deploy to Cloud Run.

## Roadmap
- [ ] Real-time notifications
- [ ] Online payment integration (WiPay/Lynk)
- [ ] Subscription plans
- [ ] Workforce mobile app
