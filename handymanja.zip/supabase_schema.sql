-- HandyManJa Supabase Schema

-- Service Requests Table
CREATE TABLE IF NOT EXISTS service_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    category TEXT NOT NULL,
    details TEXT NOT NULL,
    property_type TEXT NOT NULL,
    urgency TEXT NOT NULL,
    parish TEXT NOT NULL,
    community TEXT,
    address TEXT,
    preferred_date DATE,
    preferred_time_window TEXT,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    preferred_contact TEXT,
    attachments TEXT[], -- Array of storage URLs
    status TEXT DEFAULT 'New', -- New, Contacted, Quoted, Scheduled, In Progress, Completed, Closed
    admin_notes TEXT,
    reference_id TEXT UNIQUE
);

-- Workforce Applications Table
CREATE TABLE IF NOT EXISTS workforce_applications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    full_name TEXT NOT NULL,
    phone TEXT NOT NULL,
    email TEXT,
    parish TEXT NOT NULL,
    skills TEXT[] NOT NULL,
    years_experience TEXT,
    availability TEXT,
    transportation BOOLEAN DEFAULT FALSE,
    tools_available BOOLEAN DEFAULT FALSE,
    references TEXT,
    attachments TEXT[], -- Array of storage URLs
    status TEXT DEFAULT 'New', -- New, Approved, Rejected
    admin_notes TEXT
);

-- Enable Row Level Security (RLS)
-- Note: For MVP, we might keep it simple or set up basic policies.
-- In production, you'd restrict access to admin roles.

ALTER TABLE service_requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE workforce_applications ENABLE ROW LEVEL SECURITY;

-- Create a policy that allows anyone to insert (for public forms)
CREATE POLICY "Allow public insert for service_requests" ON service_requests FOR INSERT WITH CHECK (true);
CREATE POLICY "Allow public insert for workforce_applications" ON workforce_applications FOR INSERT WITH CHECK (true);

-- Create a policy that allows only authenticated users to read/update (for admin)
CREATE POLICY "Allow admin read for service_requests" ON service_requests FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow admin update for service_requests" ON service_requests FOR UPDATE USING (auth.role() = 'authenticated');

CREATE POLICY "Allow admin read for workforce_applications" ON workforce_applications FOR SELECT USING (auth.role() = 'authenticated');
CREATE POLICY "Allow admin update for workforce_applications" ON workforce_applications FOR UPDATE USING (auth.role() = 'authenticated');
