import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { Landmark, CheckCircle2, ShieldCheck, Clock, ArrowRight } from "lucide-react";

export default function Financing() {
  return (
    <div className="bg-stone-50">
      <section className="bg-stone-950 py-32 text-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-black sm:text-7xl mb-8"
          >
            Renovation <span className="text-emerald-500 italic serif">Financing</span>
          </motion.h1>
          <p className="mx-auto max-w-2xl text-xl text-stone-400">
            Build now, pay later. We've partnered with Jamaica's leading financial institutions to make your home improvements affordable.
          </p>
        </div>
      </section>

      <section className="py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div>
              <h2 className="text-base font-bold text-emerald-600 uppercase tracking-widest mb-6">How it Works</h2>
              <h3 className="text-4xl font-black text-stone-900 mb-8 leading-tight">
                Get the funds you need <br /> in <span className="text-emerald-600">3 simple steps.</span>
              </h3>
              
              <div className="space-y-12">
                {[
                  { step: "01", title: "Get a Quote", desc: "Request a service and get a detailed quote from HandyManJa for your project." },
                  { step: "02", title: "Apply Online", desc: "Use your quote to apply for financing through our partner portal." },
                  { step: "03", title: "Start Building", desc: "Once approved, we dispatch the team and start your project immediately." }
                ].map((item) => (
                  <div key={item.step} className="flex gap-8">
                    <span className="text-4xl font-black text-stone-200">{item.step}</span>
                    <div>
                      <h4 className="font-bold text-stone-900 mb-2">{item.title}</h4>
                      <p className="text-stone-500 text-sm leading-relaxed">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white p-12 rounded-[3rem] border border-stone-100 shadow-xl">
              <Landmark className="h-12 w-12 text-emerald-600 mb-8" />
              <h3 className="text-2xl font-bold mb-6">Partner Benefits</h3>
              <ul className="space-y-6 mb-12">
                {[
                  { title: "Competitive Rates", desc: "Access to special rates negotiated for HandyManJa customers." },
                  { title: "Fast Approval", desc: "Decisions often made within 24-48 hours." },
                  { title: "Flexible Terms", desc: "Repayment periods from 12 to 60 months." },
                  { title: "No Hidden Fees", desc: "Transparent terms with no early repayment penalties." }
                ].map((benefit) => (
                  <li key={benefit.title} className="flex gap-4">
                    <CheckCircle2 className="h-6 w-6 text-emerald-500 flex-shrink-0" />
                    <div>
                      <h4 className="font-bold text-stone-900 text-sm">{benefit.title}</h4>
                      <p className="text-stone-500 text-xs">{benefit.desc}</p>
                    </div>
                  </li>
                ))}
              </ul>
              <Link to="/request" className="premium-button-glow w-full text-center block">
                Get a Quote to Start
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
