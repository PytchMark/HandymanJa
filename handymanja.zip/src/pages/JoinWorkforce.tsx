import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion } from "motion/react";
import { workforceApplicationSchema, type WorkforceApplication } from "@/lib/validators";
import { CheckCircle2, Loader2, Upload } from "lucide-react";
import { cn } from "@/lib/utils";

const parishes = ["Kingston", "St Andrew", "St Catherine", "Other"];
const skillOptions = [
  "Plumbing", "Electrical", "AC Technician", "Farming/Agriculture", "Haulage/Trucking", 
  "Professional Mover", "Renewable Energy Specialist",
  "Container Fabricator", "Furniture Builder", "Masonry", "Carpentry", "Painting", "Landscaping", 
  "General Labour", "Cleaning", "Heavy Equipment"
];

export default function JoinWorkforce() {
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);

  const {
    register,
    handleSubmit,
    setValue,
    watch,
    formState: { errors },
  } = useForm<WorkforceApplication>({
    resolver: zodResolver(workforceApplicationSchema),
    defaultValues: {
      skills: [],
      transportation: false,
      tools_available: false,
      parish: "Kingston",
    },
  });

  const selectedSkills = watch("skills");

  const toggleSkill = (skill: string) => {
    const current = selectedSkills || [];
    if (current.includes(skill)) {
      setValue("skills", current.filter(s => s !== skill));
    } else {
      setValue("skills", [...current, skill]);
    }
  };

  const onSubmit = async (data: WorkforceApplication) => {
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/join", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      if (response.ok) {
        setSubmitted(true);
      } else {
        const res = await response.json();
        alert("Error: " + res.error);
      }
    } catch (error) {
      console.error(error);
      alert("Something went wrong.");
    } finally {
      setIsSubmitting(false);
    }
  };

  if (submitted) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 mb-8">
            <CheckCircle2 className="h-12 w-12" />
          </div>
          <h1 className="text-4xl font-black text-stone-900 mb-4">Application Sent!</h1>
          <p className="text-lg text-stone-600 mb-8">
            Thank you for applying to join the HandyManJa workforce. Our vetting team will review your profile and contact you for an interview if there's a match.
          </p>
          <button
            onClick={() => window.location.href = "/"}
            className="rounded-full bg-stone-900 px-8 py-4 text-lg font-bold text-white shadow-lg hover:bg-stone-800 transition-all"
          >
            Back to Home
          </button>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-4xl px-6 py-12 sm:py-24">
      <div className="mb-12 text-center">
        <h1 className="text-4xl font-black text-stone-900 mb-4">Join the Workforce</h1>
        <p className="text-lg text-stone-600">Get steady work, managed dispatch, and reliable payments.</p>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="bg-white p-8 sm:p-12 rounded-[2.5rem] shadow-xl border border-stone-100 space-y-8">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-stone-900">Personal Info</h2>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Full Name</label>
              <input {...register("full_name")} className="w-full rounded-2xl border-stone-200" />
              {errors.full_name && <p className="text-red-500 text-xs mt-1">{errors.full_name.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Phone Number</label>
              <input {...register("phone")} placeholder="876-000-0000" className="w-full rounded-2xl border-stone-200" />
              {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Email (Optional)</label>
              <input {...register("email")} className="w-full rounded-2xl border-stone-200" />
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Primary Parish</label>
              <select {...register("parish")} className="w-full rounded-2xl border-stone-200">
                {parishes.map(p => <option key={p} value={p}>{p}</option>)}
              </select>
            </div>
          </div>

          <div className="space-y-4">
            <h2 className="text-xl font-bold text-stone-900">Skills & Experience</h2>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Select Your Skills</label>
              <div className="flex flex-wrap gap-2">
                {skillOptions.map(skill => (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => toggleSkill(skill)}
                    className={cn(
                      "px-3 py-1.5 rounded-full text-xs font-bold border transition-all",
                      selectedSkills.includes(skill)
                        ? "bg-emerald-600 border-emerald-600 text-white"
                        : "bg-stone-50 border-stone-200 text-stone-600 hover:border-stone-300"
                    )}
                  >
                    {skill}
                  </button>
                ))}
              </div>
              {errors.skills && <p className="text-red-500 text-xs mt-1">{errors.skills.message}</p>}
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Years of Experience</label>
              <select {...register("years_experience")} className="w-full rounded-2xl border-stone-200">
                <option value="< 1 year">Less than 1 year</option>
                <option value="1-3 years">1-3 years</option>
                <option value="3-5 years">3-5 years</option>
                <option value="5+ years">5+ years</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-bold text-stone-700 mb-2">Availability</label>
              <select {...register("availability")} className="w-full rounded-2xl border-stone-200">
                <option value="Full-time">Full-time</option>
                <option value="Part-time">Part-time</option>
                <option value="Weekends Only">Weekends Only</option>
                <option value="On-call">On-call</option>
              </select>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-stone-100">
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-stone-900">Resources</h2>
            <div className="flex flex-col gap-3">
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" {...register("transportation")} className="rounded text-emerald-600 focus:ring-emerald-500" />
                <span className="text-sm font-medium">I have my own transportation</span>
              </label>
              <label className="flex items-center gap-3 cursor-pointer">
                <input type="checkbox" {...register("tools_available")} className="rounded text-emerald-600 focus:ring-emerald-500" />
                <span className="text-sm font-medium">I have my own tools</span>
              </label>
            </div>
          </div>
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-stone-900">References</h2>
            <textarea
              {...register("references")}
              placeholder="Names and phone numbers of previous clients or employers..."
              className="w-full rounded-2xl border-stone-200 h-24"
            />
          </div>
        </div>

        <div className="pt-8">
          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-emerald-600 text-white py-4 rounded-full font-bold text-lg shadow-lg hover:bg-emerald-500 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSubmitting ? <Loader2 className="h-6 w-6 animate-spin" /> : "Submit Application"}
          </button>
          <p className="mt-4 text-center text-xs text-stone-400">
            By submitting, you agree to our workforce terms and background check process.
          </p>
        </div>
      </form>
    </div>
  );
}
