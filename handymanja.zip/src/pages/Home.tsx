import { motion, useScroll, useTransform } from "motion/react";
import { 
  Droplets, Zap, Wind, Users, Package, Trash2, Trees, 
  ArrowRight, ShieldCheck, Star, Play, ChevronRight,
  Truck, Box, Recycle, Drill, Paintbrush, Shield, Layers
} from "lucide-react";
import { Link } from "react-router-dom";
import { useRef } from "react";

const services = [
  { name: "Plumbing", icon: Droplets, description: "Leaks, pipes, fixtures, and pump repairs." },
  { name: "Electrical", icon: Zap, description: "Wiring, lighting, breakers, and troubleshooting." },
  { name: "AC Service", icon: Wind, description: "Installation, cleaning, and maintenance." },
  { name: "Farming Labour", icon: Users, description: "Experienced hands for crop maintenance and harvesting." },
  { name: "Haulage & Debris", icon: Recycle, description: "Construction waste and bulk debris removal." },
  { name: "Professional Movers", icon: Box, description: "Careful packing and secure transportation." },
  { name: "Landscaping", icon: Trees, description: "Yard cleanup and garden maintenance." },
  { name: "General Labour", icon: Users, description: "Lifting, moving, and site assistance." },
];

const specialProjects = [
  { title: "Container Conversions", tag: "Architecture", img: "https://picsum.photos/seed/container/800/600" },
  { title: "Renewable Energy", tag: "Solar & Wind", img: "https://picsum.photos/seed/solar/800/600" },
  { title: "EV Charger Installs", tag: "Future-Ready", img: "https://picsum.photos/seed/ev/800/600" },
  { title: "Custom Furniture", tag: "Local Craft", img: "https://picsum.photos/seed/furniture/800/600" },
];

export default function Home() {
  const heroRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"]);
  const opacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);

  return (
    <div className="relative overflow-hidden">
      {/* Hero Section */}
      <section ref={heroRef} className="relative h-[90vh] flex items-center justify-center overflow-hidden bg-stone-950">
        <motion.div style={{ y, opacity }} className="absolute inset-0 z-0">
          <div className="absolute inset-0 bg-black/60 z-10" />
          <video 
            autoPlay 
            muted 
            loop 
            playsInline
            className="h-full w-full object-cover"
            poster="https://picsum.photos/seed/hero/1920/1080"
          >
            <source src="https://assets.mixkit.co/videos/preview/mixkit-construction-worker-working-on-a-building-site-41561-large.mp4" type="video/mp4" />
          </video>
        </motion.div>

        <div className="relative z-20 mx-auto max-w-7xl px-6 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
          >
            <span className="inline-block rounded-full bg-emerald-500/10 px-4 py-1.5 text-xs font-bold uppercase tracking-[0.2em] text-emerald-400 border border-emerald-500/20 mb-8">
              Jamaica's #1 Managed Service
            </span>
            <h1 className="text-5xl font-black tracking-tight text-white sm:text-8xl leading-[0.9]">
              Expert Help, <br />
              <span className="text-emerald-500 italic serif">Guaranteed</span> Results.
            </h1>
            <p className="mx-auto mt-8 max-w-2xl text-lg text-stone-300 leading-relaxed">
              From <span className="text-white font-bold">Plumbing</span> to <span className="text-white font-bold">Container Conversions</span>. We manage the pros, so you don't have to.
            </p>
            <div className="mt-12 flex flex-col sm:flex-row items-center justify-center gap-6">
              <Link to="/request" className="premium-button-glow w-full sm:w-auto">
                Request Service
              </Link>
              <Link to="/how-it-works" className="flex items-center gap-2 text-white font-bold hover:text-emerald-400 transition-colors">
                <div className="h-10 w-10 rounded-full border border-white/20 flex items-center justify-center">
                  <Play className="h-4 w-4 fill-current" />
                </div>
                See How It Works
              </Link>
            </div>
          </motion.div>
        </div>

        <div className="absolute bottom-12 left-1/2 -translate-x-1/2 z-20">
          <motion.div 
            animate={{ y: [0, 10, 0] }}
            transition={{ repeat: Infinity, duration: 2 }}
            className="h-12 w-6 rounded-full border-2 border-white/20 flex justify-center p-1"
          >
            <div className="h-2 w-1 bg-emerald-500 rounded-full" />
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-32 bg-white relative z-10">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between mb-20 gap-8">
            <div className="max-w-2xl">
              <h2 className="text-base font-bold text-emerald-600 uppercase tracking-widest mb-4">Our Services</h2>
              <p className="text-4xl font-black tracking-tight text-stone-900 sm:text-6xl leading-none">
                What can we <span className="text-emerald-600 italic serif">fix</span> for you today?
              </p>
            </div>
            <Link to="/services" className="group flex items-center gap-2 font-bold text-stone-900 hover:text-emerald-600 transition-colors">
              View All Services <ArrowRight className="h-5 w-5 group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {services.map((service, index) => (
              <motion.div
                key={service.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.05 }}
                viewport={{ once: true }}
                className="glow-card p-8 group"
              >
                <div className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-stone-50 text-stone-900 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-500">
                  <service.icon className="h-7 w-7" />
                </div>
                <h3 className="text-xl font-bold text-stone-900 mb-3">{service.name}</h3>
                <p className="text-sm text-stone-500 leading-relaxed">{service.description}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Special Projects (Parallax Feel) */}
      <section className="py-32 bg-stone-950 text-white overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-24">
            <h2 className="text-emerald-500 font-bold tracking-widest uppercase mb-4">Special Projects</h2>
            <p className="text-4xl font-black sm:text-6xl italic serif">Beyond the Basics</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            {specialProjects.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, scale: 0.95 }}
                whileInView={{ opacity: 1, scale: 1 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative group h-[400px] rounded-[3rem] overflow-hidden"
              >
                <img 
                  src={project.img} 
                  alt={project.title} 
                  className="absolute inset-0 h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
                  referrerPolicy="no-referrer"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/20 to-transparent" />
                <div className="absolute bottom-10 left-10">
                  <span className="text-xs font-bold uppercase tracking-widest text-emerald-400 mb-2 block">{project.tag}</span>
                  <h3 className="text-3xl font-black">{project.title}</h3>
                  <Link to="/request" className="mt-6 inline-flex items-center gap-2 text-sm font-bold text-white hover:text-emerald-400 transition-colors">
                    Start Project <ChevronRight className="h-4 w-4" />
                  </Link>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Trust Section */}
      <section className="py-32 bg-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div className="relative">
              <div className="absolute -top-12 -left-12 h-64 w-64 bg-emerald-100 rounded-full blur-3xl opacity-50" />
              <img 
                src="https://picsum.photos/seed/trust/1000/1200" 
                alt="Trust" 
                className="relative rounded-[3rem] shadow-2xl z-10"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-10 -right-10 bg-stone-900 p-10 rounded-[2.5rem] shadow-glow z-20 max-w-xs">
                <div className="flex gap-1 mb-4">
                  {[1,2,3,4,5].map(i => <Star key={i} className="h-5 w-5 fill-emerald-500 text-emerald-500" />)}
                </div>
                <p className="text-white font-bold italic serif text-xl">"The only service in Jamaica I trust with my keys."</p>
                <p className="text-stone-500 text-xs mt-4 uppercase tracking-widest">— Property Manager, Kingston</p>
              </div>
            </div>
            <div>
              <h2 className="text-base font-bold text-emerald-600 uppercase tracking-widest mb-6">Why HandyManJa?</h2>
              <h3 className="text-4xl font-black text-stone-900 mb-8 leading-tight">
                We don't just find help. <br />
                We <span className="text-emerald-600">manage</span> excellence.
              </h3>
              <div className="space-y-8">
                {[
                  { title: "Vetted Professionals", desc: "Every worker undergoes strict background and skill checks." },
                  { title: "Managed Scheduling", desc: "We handle the coordination so you don't have to wait around." },
                  { title: "Quality Guarantee", desc: "If it's not right, we fix it. No arguments, no excuses." }
                ].map((item, i) => (
                  <motion.div 
                    key={item.title}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ delay: i * 0.1 }}
                    className="flex gap-6"
                  >
                    <div className="h-12 w-12 rounded-2xl bg-emerald-50 flex items-center justify-center flex-shrink-0">
                      <ShieldCheck className="h-6 w-6 text-emerald-600" />
                    </div>
                    <div>
                      <h4 className="font-bold text-stone-900 mb-1">{item.title}</h4>
                      <p className="text-stone-500 text-sm">{item.desc}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
              <div className="mt-12">
                <Link to="/about" className="premium-button inline-block">
                  Learn Our Story
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Furniture & Financing Section */}
      <section className="py-32 bg-stone-900 text-white overflow-hidden">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
            >
              <span className="text-emerald-500 font-bold tracking-widest uppercase mb-4 block">Direct from Builder</span>
              <h2 className="text-4xl font-black mb-8 leading-tight italic serif">
                Premium Furniture. <br />
                <span className="text-emerald-500">Builder-Direct</span> Prices.
              </h2>
              <p className="text-stone-400 text-lg mb-8 leading-relaxed">
                Skip the showroom markup. We connect you directly with Jamaica's finest furniture builders. Custom builds or ready-to-ship pieces, all at a fraction of traditional store prices.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link to="/furniture" className="premium-button-glow">
                  Shop Furniture
                </Link>
                <Link to="/request" className="px-8 py-4 rounded-full border border-white/20 font-bold hover:bg-white/5 transition-all">
                  Custom Request
                </Link>
              </div>
            </motion.div>

            <motion.div
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="bg-white/5 p-12 rounded-[3rem] border border-white/10 relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 p-8 opacity-10">
                <Zap className="h-32 w-32 text-emerald-500" />
              </div>
              <h3 className="text-2xl font-bold mb-6">Renovation Financing</h3>
              <p className="text-stone-400 mb-8">
                Dreaming of a renovation but need a boost? We've partnered with leading financing institutions to offer flexible payment plans for qualified customers.
              </p>
              <ul className="space-y-4 mb-10">
                {[
                  "Low-interest rates for home repairs",
                  "Flexible repayment terms",
                  "Fast approval process",
                  "Available for solar & container projects"
                ].map((item) => (
                  <li key={item} className="flex items-center gap-3 text-sm font-medium">
                    <div className="h-2 w-2 rounded-full bg-emerald-500" />
                    {item}
                  </li>
                ))}
              </ul>
              <Link to="/financing" className="text-emerald-500 font-bold flex items-center gap-2 hover:gap-3 transition-all">
                Check Eligibility <ArrowRight className="h-4 w-4" />
              </Link>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Shop Teaser */}
      <section className="py-32 bg-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-center gap-16">
            <div className="flex-1">
              <h2 className="text-base font-bold text-emerald-600 uppercase tracking-widest mb-4">HandyManJa Shop</h2>
              <h3 className="text-4xl font-black text-stone-900 mb-6 leading-tight">
                Get the <span className="text-emerald-600">Right Tools</span> <br /> for the Job.
              </h3>
              <p className="text-stone-600 mb-8 leading-relaxed">
                We sell high-performance power tools, specialty materials, and safety equipment that are hard to find in Jamaica. From battery drills to waterproof sealants, we've got you covered with rates that are hard to beat.
              </p>
              <div className="grid grid-cols-2 gap-6 mb-10">
                <div className="flex items-center gap-3">
                  <Drill className="h-5 w-5 text-emerald-600" />
                  <span className="text-sm font-bold">Power Tools</span>
                </div>
                <div className="flex items-center gap-3">
                  <Paintbrush className="h-5 w-5 text-emerald-600" />
                  <span className="text-sm font-bold">Specialty Paints</span>
                </div>
                <div className="flex items-center gap-3">
                  <Shield className="h-5 w-5 text-emerald-600" />
                  <span className="text-sm font-bold">Safety Gear</span>
                </div>
                <div className="flex items-center gap-3">
                  <Layers className="h-5 w-5 text-emerald-600" />
                  <span className="text-sm font-bold">Productivity Tools</span>
                </div>
              </div>
              <Link to="/shop" className="premium-button">
                Visit the Shop
              </Link>
            </div>
            <div className="flex-1 relative">
              <div className="absolute -inset-4 bg-emerald-500/10 rounded-[3rem] blur-2xl" />
              <img 
                src="https://picsum.photos/seed/shop-teaser/800/600" 
                alt="Shop Tools" 
                className="relative rounded-[3rem] shadow-2xl z-10"
                referrerPolicy="no-referrer"
              />
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
