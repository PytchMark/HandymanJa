import { motion } from "motion/react";
import { useState } from "react";
import { ChevronDown, ChevronUp, HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "How does HandyManJa vet its professionals?",
    answer: "Every professional in our network undergoes a multi-stage vetting process: background checks, skill verification through practical tests, and reference checks. We only accept the top 10% of applicants."
  },
  {
    question: "Is there a warranty on the work performed?",
    answer: "Yes. All jobs managed through HandyManJa come with a standard 30-day warranty on labour. Some specialized services may carry longer warranties. If something isn't right, we'll send someone back to fix it at no extra cost."
  },
  {
    question: "How do I pay for the services?",
    answer: "We offer secure payment options including bank transfers, credit/debit cards via our secure link, and cash for smaller jobs. In Demo Mode, payments are simulated."
  },
  {
    question: "What happens if a professional is late?",
    answer: "We manage the scheduling. If a pro is delayed, our operations team will notify you immediately and provide an updated ETA. If the delay is significant, we can reschedule or dispatch another professional."
  },
  {
    question: "Do you provide materials for the job?",
    answer: "We can! You have the option to provide your own materials or have us source them for you. If we source materials, we provide a transparent quote for the cost plus a small procurement fee."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState<number | null>(0);

  return (
    <div className="bg-stone-50 py-24 sm:py-32">
      <div className="mx-auto max-w-3xl px-6 lg:px-8">
        <div className="text-center mb-20">
          <HelpCircle className="h-12 w-12 text-emerald-600 mx-auto mb-6" />
          <h1 className="text-4xl font-black text-stone-900 sm:text-6xl mb-6">Frequently Asked <span className="text-emerald-600 italic serif">Questions</span></h1>
          <p className="text-lg text-stone-600">Everything you need to know about our managed property services.</p>
        </div>

        <div className="space-y-4">
          {faqs.map((faq, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
              className="bg-white rounded-3xl border border-stone-100 overflow-hidden shadow-sm"
            >
              <button
                onClick={() => setOpenIndex(openIndex === index ? null : index)}
                className="w-full flex items-center justify-between p-8 text-left hover:bg-stone-50 transition-colors"
              >
                <span className="text-lg font-bold text-stone-900">{faq.question}</span>
                {openIndex === index ? <ChevronUp className="h-5 w-5 text-emerald-600" /> : <ChevronDown className="h-5 w-5 text-stone-400" />}
              </button>
              {openIndex === index && (
                <motion.div
                  initial={{ height: 0, opacity: 0 }}
                  animate={{ height: "auto", opacity: 1 }}
                  className="px-8 pb-8 text-stone-600 leading-relaxed"
                >
                  {faq.answer}
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        <div className="mt-20 p-12 rounded-[3rem] bg-stone-900 text-white text-center">
          <h3 className="text-2xl font-bold mb-4">Still have questions?</h3>
          <p className="text-stone-400 mb-8">Our team is ready to help you with any unique requirements.</p>
          <a href="tel:18760000000" className="premium-button-glow inline-block">
            Call Support
          </a>
        </div>
      </div>
    </div>
  );
}
