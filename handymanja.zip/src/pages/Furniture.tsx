import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { ShoppingBag, Hammer, ArrowRight, CheckCircle2, DollarSign } from "lucide-react";

const products = [
  {
    id: 1,
    name: "Mahogany Dining Table",
    price: "$125,000",
    desc: "Hand-crafted solid mahogany 6-seater.",
    img: "https://picsum.photos/seed/table/600/400"
  },
  {
    id: 2,
    name: "Modern Accent Chair",
    price: "$45,000",
    desc: "Sleek design with local cedar frame.",
    img: "https://picsum.photos/seed/chair/600/400"
  },
  {
    id: 3,
    name: "Floating Oak Shelves",
    price: "$12,000",
    desc: "Set of 3 minimalist floating shelves.",
    img: "https://picsum.photos/seed/shelf/600/400"
  },
  {
    id: 4,
    name: "Custom Bed Frame",
    price: "$85,000",
    desc: "Queen size with integrated storage.",
    img: "https://picsum.photos/seed/bed/600/400"
  }
];

export default function Furniture() {
  return (
    <div className="bg-stone-50">
      {/* Hero */}
      <section className="bg-stone-950 py-32 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img src="https://picsum.photos/seed/wood/1920/1080" alt="Wood" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
        </div>
        <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-black sm:text-7xl mb-8"
          >
            Builder <span className="text-emerald-500 italic serif">Direct</span>
          </motion.h1>
          <p className="mx-auto max-w-2xl text-xl text-stone-400">
            Premium furniture without the retail markup. Custom built by Jamaica's finest craftsmen.
          </p>
        </div>
      </section>

      {/* Value Prop */}
      <section className="py-20 bg-emerald-600 text-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div>
              <DollarSign className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <h3 className="text-xl font-bold mb-2">Cost Effective</h3>
              <p className="text-emerald-100 text-sm">Up to 40% cheaper than traditional furniture stores by cutting out the middleman.</p>
            </div>
            <div>
              <Hammer className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <h3 className="text-xl font-bold mb-2">Custom Built</h3>
              <p className="text-emerald-100 text-sm">Have a specific design in mind? Our builders can bring any vision to life.</p>
            </div>
            <div>
              <CheckCircle2 className="h-10 w-10 mx-auto mb-4 opacity-80" />
              <h3 className="text-xl font-bold mb-2">Local Quality</h3>
              <p className="text-emerald-100 text-sm">Supporting local artisans while ensuring the highest quality materials.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Catalog */}
      <section className="py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="flex items-center justify-between mb-16">
            <h2 className="text-3xl font-black text-stone-900">Available Now</h2>
            <Link to="/request" className="text-emerald-600 font-bold flex items-center gap-2">
              Request Custom Build <ArrowRight className="h-4 w-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {products.map((product) => (
              <motion.div
                key={product.id}
                whileHover={{ y: -10 }}
                className="bg-white rounded-[2rem] overflow-hidden border border-stone-100 shadow-sm"
              >
                <div className="aspect-square overflow-hidden">
                  <img src={product.img} alt={product.name} className="h-full w-full object-cover" referrerPolicy="no-referrer" />
                </div>
                <div className="p-8">
                  <h3 className="font-bold text-stone-900 mb-1">{product.name}</h3>
                  <p className="text-stone-500 text-xs mb-4">{product.desc}</p>
                  <div className="flex items-center justify-between">
                    <span className="text-lg font-black text-emerald-600">{product.price}</span>
                    <Link to="/request" className="h-10 w-10 rounded-full bg-stone-900 text-white flex items-center justify-center hover:bg-emerald-600 transition-colors">
                      <ShoppingBag className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
