import { motion } from "motion/react";
import { 
  Droplets, Zap, Wind, Users, Package, Trash2, Trees, 
  ShieldCheck, ArrowRight, Recycle, Box, Hammer, Construction,
  Sun, Wind as WindIcon, Home as HomeIcon, Warehouse
} from "lucide-react";
import { Link } from "react-router-dom";

const allServices = [
  {
    category: "Core Maintenance",
    services: [
      { name: "Plumbing", icon: Droplets, desc: "Emergency repairs, leak detection, and fixture installs." },
      { name: "Electrical", icon: Zap, desc: "Safe wiring, panel upgrades, and lighting solutions." },
      { name: "AC Service", icon: Wind, desc: "Deep cleaning, gas refills, and new installations." },
      { name: "Water Tanks", icon: Package, desc: "Tank cleaning, pump repairs, and filtration systems." },
    ]
  },
  {
    category: "Property Logistics",
    services: [
      { name: "Haulage & Debris", icon: Recycle, desc: "Construction waste removal and bulk trash clearing." },
      { name: "Professional Movers", icon: Box, desc: "Residential and commercial relocation services." },
      { name: "General Labour", icon: Users, desc: "Lifting, moving, and general site assistance." },
      { name: "Cleaning", icon: Trash2, desc: "Post-construction and deep cleaning specialists." },
    ]
  },
  {
    category: "Specialized & Agriculture",
    services: [
      { name: "Farming Labour", icon: Users, desc: "Skilled agricultural hands for crop management." },
      { name: "Landscaping", icon: Trees, desc: "Professional yard design and maintenance." },
      { name: "Renewable Energy", icon: Sun, desc: "Solar panel and wind turbine maintenance." },
      { name: "Container Conversion", icon: Warehouse, desc: "Turning containers into shops, homes, or offices." },
      { name: "Custom Furniture", icon: HomeIcon, desc: "Direct-from-builder custom furniture and repairs." },
    ]
  }
];

export default function Services() {
  return (
    <div className="bg-stone-50">
      {/* Hero */}
      <section className="bg-stone-950 py-32 text-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-black sm:text-7xl mb-8"
          >
            Our <span className="text-emerald-500 italic serif">Expertise</span>
          </motion.h1>
          <p className="mx-auto max-w-2xl text-xl text-stone-400">
            From daily maintenance to complex infrastructure projects, HandyManJa manages the best professionals in Jamaica.
          </p>
        </div>
      </section>

      {/* Services List */}
      <section className="py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {allServices.map((group, groupIndex) => (
            <div key={group.category} className="mb-32 last:mb-0">
              <div className="flex items-center gap-4 mb-12">
                <h2 className="text-2xl font-black text-stone-900">{group.category}</h2>
                <div className="h-[1px] flex-1 bg-stone-200" />
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
                {group.services.map((service, index) => (
                  <motion.div
                    key={service.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.1 }}
                    viewport={{ once: true }}
                    className="glow-card p-8 group"
                  >
                    <div className="mb-6 inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-stone-50 text-stone-900 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-500">
                      <service.icon className="h-7 w-7" />
                    </div>
                    <h3 className="text-xl font-bold text-stone-900 mb-3">{service.name}</h3>
                    <p className="text-sm text-stone-500 leading-relaxed mb-6">{service.desc}</p>
                    <Link to="/request" className="text-xs font-black uppercase tracking-widest text-emerald-600 flex items-center gap-2 group-hover:gap-3 transition-all">
                      Book Now <ArrowRight className="h-4 w-4" />
                    </Link>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Custom Request */}
      <section className="py-32 bg-emerald-900 text-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-black mb-8 italic serif">Don't see what you need?</h2>
          <p className="text-xl text-emerald-100 mb-12 max-w-2xl mx-auto">
            We handle custom "Special Projects" of all sizes. Tell us about your unique requirements and we'll build a managed team for you.
          </p>
          <Link to="/request" className="premium-button-glow">
            Request Custom Project
          </Link>
        </div>
      </section>
    </div>
  );
}
