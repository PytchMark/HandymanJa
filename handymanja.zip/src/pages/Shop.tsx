import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { 
  ShoppingBag, Hammer, ArrowRight, Shield, 
  Zap, Drill, Battery, Wrench, Paintbrush, 
  HardHat, Ruler, Layers, DollarSign, Star
} from "lucide-react";

const shopCategories = [
  {
    name: "Power Tools",
    icon: Drill,
    items: [
      { name: "20V Max Battery Drill", price: "$18,500", img: "https://picsum.photos/seed/drill/400/400", tag: "Best Seller" },
      { name: "Electric Screwdriver Set", price: "$7,500", img: "https://picsum.photos/seed/screwdriver/400/400" },
      { name: "Portable Table Saw", price: "$45,000", img: "https://picsum.photos/seed/saw/400/400", tag: "Hard to Get" },
      { name: "20V Battery Pack (5Ah)", price: "$9,000", img: "https://picsum.photos/seed/battery/400/400" },
      { name: "Fast Charger Hub", price: "$5,500", img: "https://picsum.photos/seed/charger/400/400" },
    ]
  },
  {
    name: "Specialty Materials",
    icon: Paintbrush,
    items: [
      { name: "Waterproof Roof Sealant", price: "$12,000", img: "https://picsum.photos/seed/sealant/400/400", tag: "Essential" },
      { name: "Anti-Corrosive Paint", price: "$8,500", img: "https://picsum.photos/seed/paint/400/400" },
      { name: "Industrial Adhesive", price: "$3,500", img: "https://picsum.photos/seed/glue/400/400" },
    ]
  },
  {
    name: "Safety & Productivity",
    icon: HardHat,
    items: [
      { name: "Worker Safety Kit", price: "$15,000", img: "https://picsum.photos/seed/safety/400/400", tag: "Pro Choice" },
      { name: "Precision Tile Spacers", price: "$1,200", img: "https://picsum.photos/seed/spacers/400/400" },
      { name: "Self-Leveling Laser", price: "$22,000", img: "https://picsum.photos/seed/laser/400/400" },
    ]
  }
];

export default function Shop() {
  return (
    <div className="bg-stone-50">
      {/* Hero */}
      <section className="bg-stone-950 py-32 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10">
          <img src="https://picsum.photos/seed/tools-bg/1920/1080" alt="Tools" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
        </div>
        <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <span className="text-emerald-500 font-bold tracking-widest uppercase mb-4 block">HandyManJa Shop</span>
            <h1 className="text-5xl font-black sm:text-7xl mb-8 leading-none">
              Tools That <span className="text-emerald-500 italic serif">Save Time.</span>
            </h1>
            <p className="mx-auto max-w-2xl text-xl text-stone-400">
              Rare specialty tools, high-performance materials, and safety gear at rates that are hard to beat.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Value Props */}
      <section className="py-12 border-b border-stone-200 bg-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: DollarSign, title: "Unbeatable Rates", desc: "Direct sourcing means lower prices for you." },
              { icon: Zap, title: "Hard to Get", desc: "Unique tools you won't find in local hardware stores." },
              { icon: Shield, title: "Pro Verified", desc: "Every tool is tested by our own managed workforce." },
              { icon: Star, title: "Time Savers", desc: "Productivity equipment designed to make jobs faster." }
            ].map((prop, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="h-10 w-10 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center flex-shrink-0">
                  <prop.icon className="h-5 w-5" />
                </div>
                <div>
                  <h4 className="font-bold text-stone-900 text-sm">{prop.title}</h4>
                  <p className="text-stone-500 text-xs">{prop.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Catalog */}
      <section className="py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          {shopCategories.map((category, catIndex) => (
            <div key={category.name} className="mb-32 last:mb-0">
              <div className="flex items-center justify-between mb-12">
                <div className="flex items-center gap-4">
                  <div className="h-12 w-12 rounded-2xl bg-stone-900 text-white flex items-center justify-center">
                    <category.icon className="h-6 w-6" />
                  </div>
                  <h2 className="text-3xl font-black text-stone-900">{category.name}</h2>
                </div>
                <div className="h-[1px] flex-1 bg-stone-200 mx-8 hidden md:block" />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
                {category.items.map((item, index) => (
                  <motion.div
                    key={item.name}
                    initial={{ opacity: 0, y: 20 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    viewport={{ once: true }}
                    className="glow-card overflow-hidden group"
                  >
                    <div className="aspect-square relative overflow-hidden bg-stone-100">
                      <img 
                        src={item.img} 
                        alt={item.name} 
                        className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                        referrerPolicy="no-referrer"
                      />
                      {item.tag && (
                        <div className="absolute top-4 left-4 bg-emerald-600 text-white text-[10px] font-black uppercase tracking-widest px-3 py-1 rounded-full shadow-lg">
                          {item.tag}
                        </div>
                      )}
                    </div>
                    <div className="p-8">
                      <h3 className="font-bold text-stone-900 mb-2 group-hover:text-emerald-600 transition-colors">{item.name}</h3>
                      <div className="flex items-center justify-between mt-6">
                        <span className="text-xl font-black text-stone-900">{item.price}</span>
                        <button className="h-10 w-10 rounded-full bg-stone-900 text-white flex items-center justify-center hover:bg-emerald-600 transition-colors shadow-lg">
                          <ShoppingBag className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Bulk Orders */}
      <section className="py-32 bg-stone-900 text-white">
        <div className="mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-black mb-8 italic serif">Bulk Orders & Contractor Rates</h2>
          <p className="text-xl text-stone-400 mb-12 max-w-2xl mx-auto">
            Are you a professional contractor? We offer special pricing for bulk orders of safety equipment and materials.
          </p>
          <Link to="/request" className="premium-button-glow">
            Inquire About Bulk Rates
          </Link>
        </div>
      </section>
    </div>
  );
}
