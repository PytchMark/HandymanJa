import { motion } from "motion/react";
import { 
  Search, 
  ClipboardCheck, 
  Truck, 
  ShieldCheck, 
  CreditCard, 
  MessageSquare 
} from "lucide-react";
import { Link } from "react-router-dom";

const steps = [
  {
    title: "Request Online",
    description: "Submit your request via our simple form. Tell us what's wrong, upload photos, and pick a time that works for you.",
    icon: ClipboardCheck,
    color: "bg-blue-50 text-blue-600"
  },
  {
    title: "Managed Assessment",
    description: "We review your request and provide a preliminary estimate. For complex jobs, we'll schedule a site visit.",
    icon: Search,
    color: "bg-purple-50 text-purple-600"
  },
  {
    title: "Pro Dispatched",
    description: "HandyManJa assigns a vetted professional from our network. You'll get a notification when they're on the way.",
    icon: Truck,
    color: "bg-emerald-50 text-emerald-600"
  },
  {
    title: "Quality Check",
    description: "Work is completed to our high standards. We manage the communication and ensure you're satisfied.",
    icon: ShieldCheck,
    color: "bg-amber-50 text-amber-600"
  },
  {
    title: "Secure Payment",
    description: "Pay via bank transfer, card, or cash. You'll receive a digital receipt and a warranty on the work.",
    icon: CreditCard,
    color: "bg-rose-50 text-rose-600"
  }
];

export default function HowItWorks() {
  return (
    <div className="bg-white py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl lg:text-center mb-20">
          <h2 className="text-base font-semibold leading-7 text-emerald-600 uppercase tracking-widest">Process</h2>
          <p className="mt-2 text-4xl font-black tracking-tight text-stone-900 sm:text-5xl">
            How HandyManJa Works
          </p>
          <p className="mt-6 text-lg leading-8 text-stone-600">
            We're not a public marketplace. We're a managed service. We take full responsibility for the quality, scheduling, and safety of every job.
          </p>
        </div>

        <div className="mx-auto max-w-2xl lg:max-w-none">
          <div className="grid grid-cols-1 gap-y-16 lg:grid-cols-3 lg:gap-x-12">
            {steps.map((step, index) => (
              <motion.div
                key={step.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: index * 0.1 }}
                viewport={{ once: true }}
                className="relative flex flex-col items-start"
              >
                <div className={cn("mb-6 flex h-16 w-16 items-center justify-center rounded-2xl", step.color)}>
                  <step.icon className="h-8 w-8" aria-hidden="true" />
                </div>
                <h3 className="text-xl font-bold leading-7 text-stone-900">
                  <span className="text-stone-300 mr-2">0{index + 1}</span>
                  {step.title}
                </h3>
                <p className="mt-4 text-base leading-7 text-stone-600">
                  {step.description}
                </p>
              </motion.div>
            ))}
          </div>
        </div>

        <div className="mt-24 rounded-[3rem] bg-stone-50 p-8 sm:p-16 border border-stone-100">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-stone-900 mb-6 italic serif">Why Managed Service?</h2>
              <div className="space-y-6">
                <div className="flex gap-4">
                  <div className="h-6 w-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle2 className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900">Accountability</h4>
                    <p className="text-sm text-stone-600">If something goes wrong, you call us. We own the resolution.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-6 w-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle2 className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900">Vetting</h4>
                    <p className="text-sm text-stone-600">Every worker in our network undergoes a background check and skill verification.</p>
                  </div>
                </div>
                <div className="flex gap-4">
                  <div className="h-6 w-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center flex-shrink-0 mt-1">
                    <CheckCircle2 className="h-4 w-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-stone-900">Consistency</h4>
                    <p className="text-sm text-stone-600">Standardized pricing and professional communication across all services.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://picsum.photos/seed/managed/800/800" 
                alt="Managed Service" 
                className="rounded-3xl shadow-2xl"
                referrerPolicy="no-referrer"
              />
              <div className="absolute -bottom-6 -right-6 bg-emerald-600 text-white p-8 rounded-3xl shadow-xl hidden sm:block">
                <p className="text-2xl font-black italic">"The HandyManJa Standard"</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

import { cn } from "@/lib/utils";
import { CheckCircle2 } from "lucide-react";
