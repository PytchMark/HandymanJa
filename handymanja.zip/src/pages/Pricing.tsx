import { CheckCircle2, Phone, Mail, MapPin, MessageSquare } from "lucide-react";
import { Link } from "react-router-dom";

const plans = [
  {
    name: "Standard Service",
    price: "From $3,500 JMD",
    description: "Basic repairs and maintenance tasks.",
    features: ["Vetted Professional", "Managed Dispatch", "Quality Guarantee", "Standard Scheduling"],
    cta: "Request Service",
    href: "/request"
  },
  {
    name: "Priority Service",
    price: "From $6,500 JMD",
    description: "Urgent repairs needing next-day attention.",
    features: ["Next-Day Dispatch", "Senior Technician", "Priority Support", "Detailed Assessment"],
    cta: "Request Priority",
    href: "/request",
    highlight: true
  },
  {
    name: "Emergency Service",
    price: "From $12,000 JMD",
    description: "Immediate response for critical issues.",
    features: ["Same-Day Dispatch", "24/7 Availability", "Emergency Premium", "Immediate Action"],
    cta: "Call Now",
    href: "tel:18760000000"
  }
];

export default function Pricing() {
  return (
    <div className="bg-stone-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center">
          <h1 className="text-4xl font-black tracking-tight text-stone-900 sm:text-6xl">Transparent Pricing</h1>
          <p className="mt-6 text-lg leading-8 text-stone-600">
            No hidden fees. We provide "starting from" estimates, with final quotes provided after a managed assessment.
          </p>
        </div>

        <div className="mx-auto mt-16 grid max-w-lg grid-cols-1 gap-y-6 sm:mt-20 lg:max-w-none lg:grid-cols-3 lg:gap-x-8">
          {plans.map((plan) => (
            <div
              key={plan.name}
              className={`flex flex-col justify-between rounded-3xl bg-white p-8 ring-1 ring-stone-200 xl:p-10 ${
                plan.highlight ? "scale-105 shadow-xl ring-emerald-600 z-10" : ""
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-x-4">
                  <h3 className="text-lg font-bold leading-8 text-stone-900">{plan.name}</h3>
                  {plan.highlight && (
                    <span className="rounded-full bg-emerald-600/10 px-2.5 py-1 text-xs font-bold leading-5 text-emerald-600">
                      Most Popular
                    </span>
                  )}
                </div>
                <p className="mt-4 text-sm leading-6 text-stone-600">{plan.description}</p>
                <p className="mt-6 flex items-baseline gap-x-1">
                  <span className="text-4xl font-black tracking-tight text-stone-900">{plan.price}</span>
                </p>
                <ul role="list" className="mt-8 space-y-3 text-sm leading-6 text-stone-600">
                  {plan.features.map((feature) => (
                    <li key={feature} className="flex gap-x-3">
                      <CheckCircle2 className="h-6 w-5 flex-none text-emerald-600" aria-hidden="true" />
                      {feature}
                    </li>
                  ))}
                </ul>
              </div>
              <Link
                to={plan.href}
                className={`mt-8 block rounded-full px-3 py-3 text-center text-sm font-bold leading-6 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 transition-all ${
                  plan.highlight
                    ? "bg-emerald-600 text-white shadow-sm hover:bg-emerald-500 focus-visible:outline-emerald-600"
                    : "bg-stone-900 text-white hover:bg-stone-800"
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>

        <div className="mt-24 rounded-3xl bg-stone-900 p-8 sm:p-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-white mb-4 italic serif">Waitlist: Managed Plans</h2>
              <p className="text-stone-400 mb-8">
                We're launching subscription plans for property managers and homeowners who want proactive maintenance.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="bg-stone-800 rounded-2xl p-6 border border-stone-700 flex-1">
                  <h3 className="text-emerald-400 font-bold mb-2">Home Care Plan</h3>
                  <p className="text-xs text-stone-500">Coming Soon</p>
                </div>
                <div className="bg-stone-800 rounded-2xl p-6 border border-stone-700 flex-1">
                  <h3 className="text-emerald-400 font-bold mb-2">Property Manager Plan</h3>
                  <p className="text-xs text-stone-500">Coming Soon</p>
                </div>
              </div>
            </div>
            <div className="bg-white/5 rounded-3xl p-8 border border-white/10">
              <h3 className="text-white font-bold mb-4">Pricing Rules</h3>
              <ul className="space-y-4 text-sm text-stone-400">
                <li className="flex gap-3">
                  <span className="text-emerald-500 font-bold">01</span>
                  Final quote depends on assessment/site condition.
                </li>
                <li className="flex gap-3">
                  <span className="text-emerald-500 font-bold">02</span>
                  Service-call fee applies to all site visits (deductible from job total).
                </li>
                <li className="flex gap-3">
                  <span className="text-emerald-500 font-bold">03</span>
                  Emergency premiums apply for after-hours and same-day requests.
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
