import { motion } from "motion/react";
import { Shield, Users, Target, Heart, CheckCircle2, ArrowRight } from "lucide-react";
import { Link } from "react-router-dom";

export default function About() {
  return (
    <div className="bg-white">
      {/* Hero */}
      <section className="relative py-32 overflow-hidden bg-stone-950 text-white">
        <div className="absolute inset-0 opacity-20">
          <img src="https://picsum.photos/seed/jamaica/1920/1080" alt="Jamaica" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
        </div>
        <div className="relative z-10 mx-auto max-w-7xl px-6 lg:px-8 text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <h1 className="text-5xl font-black sm:text-7xl mb-8 leading-none">
              Built for <span className="text-emerald-500 italic serif">Jamaica</span>, <br />
              by Jamaicans.
            </h1>
            <p className="mx-auto max-w-2xl text-xl text-stone-400 leading-relaxed">
              HandyManJa was born from a simple frustration: finding reliable, skilled help shouldn't be a full-time job. We're here to change the standard of property services in the Caribbean.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Mission */}
      <section className="py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-center">
            <div>
              <h2 className="text-base font-bold text-emerald-600 uppercase tracking-widest mb-6">Our Mission</h2>
              <h3 className="text-4xl font-black text-stone-900 mb-8 leading-tight">
                Empowering the <span className="text-emerald-600">Workforce</span>, <br />
                Protecting the Homeowner.
              </h3>
              <p className="text-stone-600 mb-8 leading-relaxed">
                We believe that skilled tradespeople are the backbone of our economy. By providing them with a managed platform, we ensure they get fair pay and consistent work, while homeowners get the peace of mind they deserve.
              </p>
              <div className="grid grid-cols-2 gap-8">
                <div className="p-6 rounded-3xl bg-stone-50 border border-stone-100">
                  <h4 className="text-3xl font-black text-stone-900 mb-2">500+</h4>
                  <p className="text-xs text-stone-500 uppercase tracking-widest font-bold">Vetted Pros</p>
                </div>
                <div className="p-6 rounded-3xl bg-stone-50 border border-stone-100">
                  <h4 className="text-3xl font-black text-stone-900 mb-2">12k+</h4>
                  <p className="text-xs text-stone-500 uppercase tracking-widest font-bold">Jobs Completed</p>
                </div>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-[4/5] rounded-[3rem] overflow-hidden shadow-2xl">
                <img src="https://picsum.photos/seed/team/800/1000" alt="Team" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
              </div>
              <div className="absolute -bottom-10 -left-10 bg-emerald-600 p-10 rounded-[2.5rem] shadow-glow text-white max-w-xs">
                <p className="font-bold italic serif text-xl">"We're not just a directory. We're your property partner."</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-32 bg-stone-50">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="text-center mb-20">
            <h2 className="text-emerald-600 font-bold tracking-widest uppercase mb-4">Our Values</h2>
            <p className="text-4xl font-black text-stone-900 sm:text-5xl italic serif">The HandyManJa Way</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { title: "Radical Transparency", icon: Shield, desc: "No hidden fees. No surprise costs. We quote clearly and stick to it." },
              { title: "Community First", icon: Users, desc: "We invest in our workers, providing training and support to help them grow." },
              { title: "Uncompromising Quality", icon: Target, desc: "We don't settle for 'good enough'. We aim for 'mesmerizing' results." }
            ].map((value, i) => (
              <motion.div
                key={value.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.1 }}
                className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-stone-100"
              >
                <div className="h-14 w-14 rounded-2xl bg-emerald-50 text-emerald-600 flex items-center justify-center mb-8">
                  <value.icon className="h-7 w-7" />
                </div>
                <h4 className="text-xl font-bold text-stone-900 mb-4">{value.title}</h4>
                <p className="text-stone-500 text-sm leading-relaxed">{value.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="relative rounded-[4rem] bg-stone-950 p-12 sm:p-24 overflow-hidden text-center">
            <div className="absolute inset-0 opacity-10">
              <img src="https://picsum.photos/seed/cta/1920/1080" alt="CTA" className="h-full w-full object-cover" referrerPolicy="no-referrer" />
            </div>
            <div className="relative z-10">
              <h2 className="text-4xl font-black text-white sm:text-6xl mb-8">Ready to experience <br /> the <span className="text-emerald-500">difference?</span></h2>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-6">
                <Link to="/request" className="premium-button-glow">
                  Book a Service
                </Link>
                <Link to="/join" className="text-white font-bold hover:text-emerald-400 transition-colors flex items-center gap-2">
                  Join the Workforce <ArrowRight className="h-5 w-5" />
                </Link>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
