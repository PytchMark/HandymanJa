import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { motion, AnimatePresence } from "motion/react";
import { serviceRequestSchema, type ServiceRequest } from "@/lib/validators";
import { CheckCircle2, Loader2, MessageSquare, Upload, ArrowRight, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";

const parishes = ["Kingston", "St Andrew", "St Catherine"];
const categories = [
  "Plumbing", "Electrical", "AC Service", "Farming Labour", "Haulage & Debris Removal", 
  "Professional Movers", "Renewable Energy (Solar/Wind)", 
  "Container Conversion", "Custom Furniture", "Tool Rental", "Water Tank Cleaning", 
  "Cleaning", "Landscaping", "General Labour", "Special Project"
];
const propertyTypes = ["Residential", "Commercial", "Industrial", "Strata/Complex"];
const urgencies = ["Standard (2-3 days)", "Priority (Next Day)", "Emergency (Same Day)"];

export default function RequestService() {
  const [step, setStep] = useState(1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState<{ referenceId: string; whatsappLink: string } | null>(null);

  const {
    register,
    handleSubmit,
    watch,
    setValue,
    formState: { errors },
  } = useForm<ServiceRequest>({
    resolver: zodResolver(serviceRequestSchema),
    defaultValues: {
      category: "",
      urgency: "Standard (2-3 days)",
      property_type: "Residential",
      parish: "Kingston",
      preferred_contact: "WhatsApp",
      attachments: [],
    },
  });

  const onSubmit = async (data: ServiceRequest) => {
    setIsSubmitting(true);
    try {
      const response = await fetch("/api/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
      });
      const resData = await response.json();
      if (response.ok) {
        setResult(resData);
        setStep(6); // Success step
      } else {
        alert("Error: " + resData.error);
      }
    } catch (error) {
      console.error(error);
      alert("Something went wrong. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const nextStep = () => setStep((s) => s + 1);
  const prevStep = () => setStep((s) => s - 1);

  const selectedCategory = watch("category");

  if (step === 6 && result) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-24 text-center">
        <motion.div initial={{ scale: 0.9, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}>
          <div className="mx-auto flex h-20 w-20 items-center justify-center rounded-full bg-emerald-100 text-emerald-600 mb-8">
            <CheckCircle2 className="h-12 w-12" />
          </div>
          <h1 className="text-4xl font-black text-stone-900 mb-4">Request Received!</h1>
          <p className="text-lg text-stone-600 mb-8">
            Your reference ID is <span className="font-bold text-emerald-600">{result.referenceId}</span>. 
            An operations manager will contact you shortly to confirm pricing and dispatch.
          </p>
          <div className="flex flex-col gap-4">
            <a
              href={result.whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-2 rounded-full bg-emerald-600 px-8 py-4 text-lg font-bold text-white shadow-lg hover:bg-emerald-500 transition-all"
            >
              <MessageSquare className="h-6 w-6" />
              Continue on WhatsApp
            </a>
            <button
              onClick={() => window.location.href = "/"}
              className="text-stone-500 font-semibold hover:text-stone-900"
            >
              Back to Home
            </button>
          </div>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-6 py-12 sm:py-24">
      <div className="mb-12">
        <div className="flex items-center justify-between mb-4">
          <h1 className="text-3xl font-black text-stone-900">Request Service</h1>
          <span className="text-sm font-bold text-stone-400">Step {step} of 5</span>
        </div>
        <div className="h-2 w-full bg-stone-100 rounded-full overflow-hidden">
          <motion.div 
            className="h-full bg-emerald-600"
            initial={{ width: "0%" }}
            animate={{ width: `${(step / 5) * 100}%` }}
          />
        </div>
      </div>

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-8">
        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.div
              key="step1"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-bold text-stone-900">What do you need help with?</h2>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                {categories.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    onClick={() => {
                      setValue("category", cat);
                      nextStep();
                    }}
                    className={cn(
                      "p-4 rounded-2xl border-2 text-sm font-bold transition-all text-center",
                      selectedCategory === cat 
                        ? "border-emerald-600 bg-emerald-50 text-emerald-700" 
                        : "border-stone-100 bg-white text-stone-600 hover:border-stone-200"
                    )}
                  >
                    {cat}
                  </button>
                ))}
              </div>
              {errors.category && <p className="text-red-500 text-xs">{errors.category.message}</p>}
            </motion.div>
          )}

          {step === 2 && (
            <motion.div
              key="step2"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-bold text-stone-900">Tell us about the job</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Job Details</label>
                  <textarea
                    {...register("details")}
                    placeholder="Describe the issue, what needs fixing, or what you want built..."
                    className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500 h-32"
                  />
                  {errors.details && <p className="text-red-500 text-xs mt-1">{errors.details.message}</p>}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-stone-700 mb-2">Property Type</label>
                    <select
                      {...register("property_type")}
                      className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                    >
                      {propertyTypes.map(t => <option key={t} value={t}>{t}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-stone-700 mb-2">Urgency</label>
                    <select
                      {...register("urgency")}
                      className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                    >
                      {urgencies.map(u => <option key={u} value={u}>{u}</option>)}
                    </select>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-stone-700 mb-2">Parish</label>
                    <select
                      {...register("parish")}
                      className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                    >
                      {parishes.map(p => <option key={p} value={p}>{p}</option>)}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-stone-700 mb-2">Community/Area</label>
                    <input
                      {...register("community")}
                      placeholder="e.g. Barbican, Portmore..."
                      className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>
              </div>
              <div className="flex justify-between">
                <button type="button" onClick={prevStep} className="flex items-center gap-2 font-bold text-stone-500"><ArrowLeft className="h-4 w-4" /> Back</button>
                <button type="button" onClick={nextStep} className="bg-stone-900 text-white px-8 py-3 rounded-full font-bold flex items-center gap-2">Next <ArrowRight className="h-4 w-4" /></button>
              </div>
            </motion.div>
          )}

          {step === 3 && (
            <motion.div
              key="step3"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-bold text-stone-900">Upload Photos (Optional)</h2>
              <p className="text-stone-500 text-sm">Photos help us provide a more accurate quote faster.</p>
              <div className="border-2 border-dashed border-stone-200 rounded-3xl p-12 text-center hover:border-emerald-500 transition-colors cursor-pointer">
                <Upload className="h-12 w-12 text-stone-300 mx-auto mb-4" />
                <p className="text-sm font-bold text-stone-600">Click to upload or drag and drop</p>
                <p className="text-xs text-stone-400 mt-1">PNG, JPG up to 10MB</p>
                <input type="file" multiple className="hidden" />
              </div>
              <div className="flex justify-between">
                <button type="button" onClick={prevStep} className="flex items-center gap-2 font-bold text-stone-500"><ArrowLeft className="h-4 w-4" /> Back</button>
                <button type="button" onClick={nextStep} className="bg-stone-900 text-white px-8 py-3 rounded-full font-bold flex items-center gap-2">Next <ArrowRight className="h-4 w-4" /></button>
              </div>
            </motion.div>
          )}

          {step === 4 && (
            <motion.div
              key="step4"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-bold text-stone-900">When should we come?</h2>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Preferred Date</label>
                  <input
                    type="date"
                    {...register("preferred_date")}
                    className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Time Window</label>
                  <select
                    {...register("preferred_time_window")}
                    className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                  >
                    <option value="Morning (8AM - 12PM)">Morning (8AM - 12PM)</option>
                    <option value="Afternoon (12PM - 4PM)">Afternoon (12PM - 4PM)</option>
                    <option value="Evening (4PM - 7PM)">Evening (4PM - 7PM)</option>
                  </select>
                </div>
              </div>
              <div className="flex justify-between">
                <button type="button" onClick={prevStep} className="flex items-center gap-2 font-bold text-stone-500"><ArrowLeft className="h-4 w-4" /> Back</button>
                <button type="button" onClick={nextStep} className="bg-stone-900 text-white px-8 py-3 rounded-full font-bold flex items-center gap-2">Next <ArrowRight className="h-4 w-4" /></button>
              </div>
            </motion.div>
          )}

          {step === 5 && (
            <motion.div
              key="step5"
              initial={{ x: 20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              exit={{ x: -20, opacity: 0 }}
              className="space-y-6"
            >
              <h2 className="text-xl font-bold text-stone-900">Contact Information</h2>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Full Name</label>
                  <input
                    {...register("name")}
                    placeholder="Enter your name"
                    className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                  />
                  {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name.message}</p>}
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-bold text-stone-700 mb-2">Phone Number</label>
                    <input
                      {...register("phone")}
                      placeholder="876-000-0000"
                      className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                    {errors.phone && <p className="text-red-500 text-xs mt-1">{errors.phone.message}</p>}
                  </div>
                  <div>
                    <label className="block text-sm font-bold text-stone-700 mb-2">Email (Optional)</label>
                    <input
                      {...register("email")}
                      placeholder="email@example.com"
                      className="w-full rounded-2xl border-stone-200 focus:border-emerald-500 focus:ring-emerald-500"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-bold text-stone-700 mb-2">Preferred Contact Method</label>
                  <div className="flex gap-4">
                    {["WhatsApp", "Phone Call", "Email"].map(m => (
                      <label key={m} className="flex items-center gap-2 cursor-pointer">
                        <input type="radio" value={m} {...register("preferred_contact")} className="text-emerald-600 focus:ring-emerald-500" />
                        <span className="text-sm font-medium">{m}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
              <div className="flex justify-between">
                <button type="button" onClick={prevStep} className="flex items-center gap-2 font-bold text-stone-500"><ArrowLeft className="h-4 w-4" /> Back</button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="bg-emerald-600 text-white px-12 py-4 rounded-full font-bold flex items-center gap-2 shadow-lg hover:bg-emerald-500 disabled:opacity-50"
                >
                  {isSubmitting ? <Loader2 className="h-5 w-5 animate-spin" /> : "Submit Request"}
                </button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </form>
    </div>
  );
}
