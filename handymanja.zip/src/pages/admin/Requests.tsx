import { useState, useEffect } from "react";
import { supabase, isSupabaseConfigured } from "@/lib/supabase";
import { useAppStore } from "@/lib/store";
import { Loader2, ExternalLink, Clock, MapPin, AlertCircle, Database } from "lucide-react";
import { format } from "date-fns";
import { cn } from "@/lib/utils";

const MOCK_REQUESTS = [
  {
    id: "1",
    reference_id: "HMJ-DEMO1",
    category: "Plumbing",
    name: "John Doe",
    phone: "876-555-0123",
    parish: "Kingston",
    community: "Barbican",
    urgency: "Emergency (Same Day)",
    status: "New",
    created_at: new Date().toISOString()
  },
  {
    id: "2",
    reference_id: "HMJ-DEMO2",
    category: "Electrical",
    name: "Jane Smith",
    phone: "876-555-0456",
    parish: "St Andrew",
    community: "Half Way Tree",
    urgency: "Standard (2-3 days)",
    status: "Contacted",
    created_at: new Date().toISOString()
  }
];

export default function AdminRequests() {
  const [requests, setRequests] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const { isAdmin } = useAppStore();

  useEffect(() => {
    fetchRequests();
  }, []);

  const fetchRequests = async () => {
    setLoading(true);
    if (!isSupabaseConfigured) {
      setRequests(MOCK_REQUESTS);
      setLoading(false);
      return;
    }

    const { data, error } = await supabase
      .from("service_requests")
      .select("*")
      .order("created_at", { ascending: false });
    
    if (data) setRequests(data);
    setLoading(false);
  };

  const updateStatus = async (id: string, status: string) => {
    if (!isSupabaseConfigured) {
      setRequests(requests.map(r => r.id === id ? { ...r, status } : r));
      return;
    }

    const { error } = await supabase
      .from("service_requests")
      .update({ status })
      .eq("id", id);
    
    if (!error) {
      setRequests(requests.map(r => r.id === id ? { ...r, status } : r));
    }
  };

  if (loading) {
    return (
      <div className="flex h-96 items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-6 py-12">
      {!isSupabaseConfigured && (
        <div className="mb-8 flex items-center gap-3 rounded-2xl bg-amber-50 p-4 text-amber-800 border border-amber-200">
          <Database className="h-5 w-5" />
          <p className="text-sm font-medium">
            <strong>Demo Mode:</strong> Supabase is not connected. Showing sample data.
          </p>
        </div>
      )}
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-black text-stone-900">Service Requests</h1>
        <button 
          onClick={fetchRequests}
          className="text-sm font-bold text-emerald-600 hover:text-emerald-500"
        >
          Refresh
        </button>
      </div>

      <div className="overflow-hidden rounded-3xl border border-stone-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-stone-50 border-b border-stone-200">
              <tr>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-wider text-stone-500">Ref / Category</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-wider text-stone-500">Customer</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-wider text-stone-500">Location</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-wider text-stone-500">Urgency</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-wider text-stone-500">Status</th>
                <th className="px-6 py-4 text-xs font-black uppercase tracking-wider text-stone-500">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-100">
              {requests.map((req) => (
                <tr key={req.id} className="hover:bg-stone-50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-bold text-stone-900">{req.reference_id}</div>
                    <div className="text-xs text-stone-500">{req.category}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="font-medium text-stone-900">{req.name}</div>
                    <div className="text-xs text-stone-500">{req.phone}</div>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-1 text-xs text-stone-900">
                      <MapPin className="h-3 w-3 text-stone-400" />
                      {req.parish}
                    </div>
                    <div className="text-[10px] text-stone-500">{req.community}</div>
                  </td>
                  <td className="px-6 py-4">
                    <span className={cn(
                      "inline-flex items-center rounded-full px-2 py-1 text-[10px] font-bold",
                      req.urgency.includes("Emergency") ? "bg-red-50 text-red-700" : "bg-blue-50 text-blue-700"
                    )}>
                      {req.urgency}
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <select
                      value={req.status}
                      onChange={(e) => updateStatus(req.id, e.target.value)}
                      className="text-xs font-bold rounded-lg border-stone-200 py-1 pl-2 pr-8 focus:ring-emerald-500"
                    >
                      {["New", "Contacted", "Quoted", "Scheduled", "In Progress", "Completed", "Closed"].map(s => (
                        <option key={s} value={s}>{s}</option>
                      ))}
                    </select>
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-stone-400 hover:text-emerald-600">
                      <ExternalLink className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
