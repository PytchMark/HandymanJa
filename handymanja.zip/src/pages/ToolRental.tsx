import { motion } from "motion/react";
import { Link } from "react-router-dom";
import { Hammer, Drill, Construction, Truck, CheckCircle2 } from "lucide-react";

const tools = [
  { name: "Jackhammer", price: "$4,500/day", category: "Demolition" },
  { name: "Cement Mixer", price: "$6,000/day", category: "Construction" },
  { name: "Pressure Washer", price: "$3,500/day", category: "Cleaning" },
  { name: "Scaffolding Set", price: "$2,500/day", category: "Access" },
  { name: "Power Drill Set", price: "$1,500/day", category: "General" },
  { name: "Lawn Mower", price: "$3,000/day", category: "Landscaping" },
];

export default function ToolRental() {
  return (
    <div className="bg-stone-50 py-24 sm:py-32">
      <div className="mx-auto max-w-7xl px-6 lg:px-8">
        <div className="mx-auto max-w-2xl text-center mb-16">
          <h1 className="text-4xl font-black tracking-tight text-stone-900 sm:text-6xl">Tool Rental</h1>
          <p className="mt-6 text-lg leading-8 text-stone-600">
            Professional-grade construction and maintenance tools. Delivered to your site. Managed by HandyManJa.
          </p>
        </div>

        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {tools.map((tool) => (
            <div key={tool.name} className="bg-white p-8 rounded-3xl shadow-sm border border-stone-100 flex flex-col justify-between">
              <div>
                <div className="flex items-center justify-between mb-4">
                  <span className="text-[10px] font-black uppercase tracking-widest text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md">
                    {tool.category}
                  </span>
                  <Hammer className="h-5 w-5 text-stone-300" />
                </div>
                <h3 className="text-xl font-bold text-stone-900">{tool.name}</h3>
                <p className="mt-2 text-2xl font-black text-emerald-600">{tool.price}</p>
              </div>
              <Link
                to="/request"
                className="mt-8 block rounded-full bg-stone-900 px-6 py-3 text-center text-sm font-bold text-white hover:bg-stone-800 transition-all"
              >
                Reserve Tool
              </Link>
            </div>
          ))}
        </div>

        <div className="mt-24 rounded-[3rem] bg-emerald-900 p-8 sm:p-16 text-white">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6 italic serif">Rental Terms</h2>
              <ul className="space-y-4">
                {[
                  "Refundable security deposit required.",
                  "Delivery and pickup available for a flat fee.",
                  "Tools are inspected and maintained after every use.",
                  "Operator available for hire with heavy machinery."
                ].map((term) => (
                  <li key={term} className="flex gap-3 text-emerald-100">
                    <CheckCircle2 className="h-5 w-5 text-emerald-400 flex-shrink-0" />
                    {term}
                  </li>
                ))}
              </ul>
            </div>
            <div className="flex flex-col gap-4">
              <div className="bg-white/10 p-6 rounded-2xl border border-white/10">
                <Truck className="h-8 w-8 text-emerald-400 mb-4" />
                <h4 className="font-bold">Next-Day Delivery</h4>
                <p className="text-sm text-emerald-100/70">Order by 2PM for next-day delivery to your site.</p>
              </div>
              <div className="bg-white/10 p-6 rounded-2xl border border-white/10">
                <Construction className="h-8 w-8 text-emerald-400 mb-4" />
                <h4 className="font-bold">Operator Support</h4>
                <p className="text-sm text-emerald-100/70">Need someone to run the machine? We can dispatch an operator.</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
