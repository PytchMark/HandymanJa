import { z } from "zod";

export const serviceRequestSchema = z.object({
  category: z.string().min(1, "Please select a category"),
  details: z.string().min(10, "Please provide more details about the job"),
  property_type: z.string().min(1, "Please select property type"),
  urgency: z.string().min(1, "Please select urgency level"),
  parish: z.string().min(1, "Please select your parish"),
  community: z.string().optional(),
  address: z.string().optional(),
  preferred_date: z.string().optional(),
  preferred_time_window: z.string().optional(),
  name: z.string().min(2, "Full name is required"),
  phone: z.string().min(10, "Valid Jamaican phone number required"),
  email: z.string().email("Invalid email address").optional().or(z.literal("")),
  preferred_contact: z.string().min(1, "Select preferred contact method"),
  attachments: z.array(z.string()).optional(),
});

export const workforceApplicationSchema = z.object({
  full_name: z.string().min(2, "Full name is required"),
  phone: z.string().min(10, "Valid phone number required"),
  email: z.string().email().optional().or(z.literal("")),
  parish: z.string().min(1, "Select your parish"),
  skills: z.array(z.string()).min(1, "Select at least one skill"),
  years_experience: z.string().min(1, "Required"),
  availability: z.string().min(1, "Required"),
  transportation: z.boolean(),
  tools_available: z.boolean(),
  references: z.string().optional(),
  attachments: z.array(z.string()).optional(),
});

export type ServiceRequest = z.infer<typeof serviceRequestSchema>;
export type WorkforceApplication = z.infer<typeof workforceApplicationSchema>;
