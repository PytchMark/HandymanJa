import { create } from 'zustand';

interface AppState {
  isAdmin: boolean;
  setIsAdmin: (val: boolean) => void;
}

export const useAppStore = create<AppState>((set) => ({
  isAdmin: false,
  setIsAdmin: (val) => set({ isAdmin: val }),
}));
