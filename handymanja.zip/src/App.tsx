import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Layout from "./components/Layout";
import Home from "./pages/Home";
import Services from "./pages/Services";
import Pricing from "./pages/Pricing";
import HowItWorks from "./pages/HowItWorks";
import RequestService from "./pages/RequestService";
import JoinWorkforce from "./pages/JoinWorkforce";
import AdminRequests from "./pages/admin/Requests";
import ToolRental from "./pages/ToolRental";
import About from "./pages/About";
import FAQ from "./pages/FAQ";
import Furniture from "./pages/Furniture";
import Financing from "./pages/Financing";
import Shop from "./pages/Shop";

// Placeholder for missing pages
const Placeholder = ({ title }: { title: string }) => (
  <div className="mx-auto max-w-7xl px-6 py-24">
    <h1 className="text-4xl font-black text-stone-900 mb-4">{title}</h1>
    <p className="text-stone-600">This page is currently under construction. Please check back soon.</p>
  </div>
);

export default function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/services" element={<Services />} />
          <Route path="/pricing" element={<Pricing />} />
          <Route path="/how-it-works" element={<HowItWorks />} />
          <Route path="/request" element={<RequestService />} />
          <Route path="/join" element={<JoinWorkforce />} />
          <Route path="/tools" element={<ToolRental />} />
          <Route path="/about" element={<About />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path="/furniture" element={<Furniture />} />
          <Route path="/financing" element={<Financing />} />
          <Route path="/shop" element={<Shop />} />
          
          <Route path="/contact" element={<Placeholder title="Contact" />} />
          <Route path="/terms" element={<Placeholder title="Terms of Service" />} />
          <Route path="/privacy" element={<Placeholder title="Privacy Policy" />} />

          {/* Admin Routes */}
          <Route path="/admin/login" element={<Placeholder title="Admin Login" />} />
          <Route path="/admin/requests" element={<AdminRequests />} />
          <Route path="/admin/workforce" element={<Placeholder title="Workforce Management" />} />
        </Routes>
      </Layout>
    </Router>
  );
}
