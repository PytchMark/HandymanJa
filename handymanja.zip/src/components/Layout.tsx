import { ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { Menu, X, Phone, MessageSquare, Database, ChevronDown, ShoppingBag, Hammer, Shield, Zap } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";
import { isSupabaseConfigured } from "@/lib/supabase";
import LoadingScreen from "./LoadingScreen";

const navigation = [
  { 
    name: "Services", 
    href: "/services",
    dropdown: [
      { name: "Core Maintenance", href: "/services#core" },
      { name: "Logistics & Haulage", href: "/services#logistics" },
      { name: "Special Projects", href: "/services#special" },
      { name: "Custom Furniture", href: "/furniture" },
    ]
  },
  { 
    name: "Shop", 
    href: "/shop",
    dropdown: [
      { name: "Power Tools", href: "/shop#tools" },
      { name: "Specialty Materials", href: "/shop#materials" },
      { name: "Safety Gear", href: "/shop#safety" },
      { name: "Tool Rental", href: "/tools" },
    ]
  },
  { name: "Pricing", href: "/pricing" },
  { name: "Financing", href: "/financing" },
  { name: "About Us", href: "/about" },
];

export default function Layout({ children }: { children: ReactNode }) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const location = useLocation();
  const dropdownRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setActiveDropdown(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="min-h-screen bg-stone-50 font-sans text-stone-900">
      <LoadingScreen />
      {!isSupabaseConfigured && (
        <div className="bg-emerald-600 text-white py-2 px-4 text-center text-xs font-bold flex items-center justify-center gap-2 relative z-[60]">
          <Database className="h-3 w-3" />
          DEMO MODE: Connect Supabase in settings to enable real data storage.
        </div>
      )}
      <header className="sticky top-0 z-50 border-b border-stone-200 bg-white/80 backdrop-blur-md">
        <nav className="mx-auto flex max-w-7xl items-center justify-between p-4 lg:px-8" aria-label="Global">
          <div className="flex lg:flex-1">
            <Link to="/" className="-m-1.5 p-1.5 flex items-center gap-2">
              <span className="text-2xl font-black tracking-tighter text-emerald-600">HandyManJa</span>
            </Link>
          </div>
          <div className="flex lg:hidden">
            <button
              type="button"
              className="-m-2.5 inline-flex items-center justify-center rounded-md p-2.5 text-stone-700"
              onClick={() => setMobileMenuOpen(true)}
            >
              <Menu className="h-6 w-6" aria-hidden="true" />
            </button>
          </div>
          <div className="hidden lg:flex lg:gap-x-8" ref={dropdownRef}>
            {navigation.map((item) => (
              <div key={item.name} className="relative group">
                {item.dropdown ? (
                  <button
                    onClick={() => setActiveDropdown(activeDropdown === item.name ? null : item.name)}
                    className={cn(
                      "flex items-center gap-1 text-sm font-semibold leading-6 transition-colors hover:text-emerald-600",
                      location.pathname.startsWith(item.href) || activeDropdown === item.name ? "text-emerald-600" : "text-stone-600"
                    )}
                  >
                    {item.name}
                    <ChevronDown className={cn("h-4 w-4 transition-transform", activeDropdown === item.name && "rotate-180")} />
                  </button>
                ) : (
                  <Link
                    to={item.href}
                    className={cn(
                      "text-sm font-semibold leading-6 transition-colors hover:text-emerald-600",
                      location.pathname === item.href ? "text-emerald-600" : "text-stone-600"
                    )}
                  >
                    {item.name}
                  </Link>
                )}

                {item.dropdown && activeDropdown === item.name && (
                  <div className="absolute left-0 top-full mt-2 w-56 rounded-2xl bg-white p-2 shadow-xl ring-1 ring-stone-900/5 animate-in fade-in slide-in-from-top-2">
                    {item.dropdown.map((subItem) => (
                      <Link
                        key={subItem.name}
                        to={subItem.href}
                        onClick={() => setActiveDropdown(null)}
                        className="block rounded-xl px-4 py-2.5 text-sm font-semibold text-stone-700 hover:bg-stone-50 hover:text-emerald-600"
                      >
                        {subItem.name}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
          <div className="hidden lg:flex lg:flex-1 lg:justify-end lg:gap-x-4">
            <Link
              to="/request"
              className="rounded-full bg-emerald-600 px-6 py-2.5 text-sm font-semibold text-white shadow-sm hover:bg-emerald-500 transition-all"
            >
              Request Service
            </Link>
          </div>
        </nav>
        
        {/* Mobile menu */}
        <div className={cn("lg:hidden", mobileMenuOpen ? "fixed inset-0 z-50" : "hidden")}>
          <div className="fixed inset-y-0 right-0 z-50 w-full overflow-y-auto bg-white px-6 py-6 sm:max-w-sm sm:ring-1 sm:ring-stone-900/10">
            <div className="flex items-center justify-between">
              <Link to="/" className="-m-1.5 p-1.5" onClick={() => setMobileMenuOpen(false)}>
                <span className="text-2xl font-black tracking-tighter text-emerald-600">HandyManJa</span>
              </Link>
              <button
                type="button"
                className="-m-2.5 rounded-md p-2.5 text-stone-700"
                onClick={() => setMobileMenuOpen(false)}
              >
                <X className="h-6 w-6" aria-hidden="true" />
              </button>
            </div>
            <div className="mt-6 flow-root">
              <div className="-my-6 divide-y divide-stone-500/10">
                <div className="space-y-2 py-6">
                  {navigation.map((item) => (
                    <div key={item.name} className="space-y-1">
                      <Link
                        to={item.href}
                        className="-block rounded-lg px-3 py-2 text-base font-semibold leading-7 text-stone-900 hover:bg-stone-50"
                        onClick={() => setMobileMenuOpen(false)}
                      >
                        {item.name}
                      </Link>
                      {item.dropdown && (
                        <div className="pl-6 space-y-1">
                          {item.dropdown.map((subItem) => (
                            <Link
                              key={subItem.name}
                              to={subItem.href}
                              className="block rounded-lg px-3 py-1.5 text-sm font-medium text-stone-600 hover:bg-stone-50"
                              onClick={() => setMobileMenuOpen(false)}
                            >
                              {subItem.name}
                            </Link>
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                <div className="py-6 flex flex-col gap-4">
                  <Link
                    to="/request"
                    className="rounded-full bg-emerald-600 px-6 py-3 text-center text-base font-semibold text-white shadow-sm hover:bg-emerald-500"
                    onClick={() => setMobileMenuOpen(false)}
                  >
                    Request Service
                  </Link>
                  <a
                    href="https://wa.me/18760000000"
                    className="flex items-center justify-center gap-2 rounded-full border border-stone-200 px-6 py-3 text-center text-base font-semibold text-stone-900 hover:bg-stone-50"
                  >
                    <MessageSquare className="h-5 w-5 text-emerald-500" />
                    WhatsApp Now
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <main>{children}</main>

      <footer className="bg-stone-900 text-stone-300 py-12">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <span className="text-2xl font-black tracking-tighter text-white">HandyManJa</span>
              <p className="mt-4 text-sm leading-6 max-w-md">
                Jamaica’s premier managed workforce network. We vet the workers, we manage the quality, you get the results.
              </p>
              <div className="mt-6 flex gap-4">
                <a href="#" className="hover:text-white transition-colors">Facebook</a>
                <a href="#" className="hover:text-white transition-colors">Instagram</a>
                <a href="#" className="hover:text-white transition-colors">LinkedIn</a>
              </div>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Company</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link to="/about" className="hover:text-white">About Us</Link></li>
                <li><Link to="/how-it-works" className="hover:text-white">How It Works</Link></li>
                <li><Link to="/contact" className="hover:text-white">Contact</Link></li>
                <li><Link to="/faq" className="hover:text-white">FAQ</Link></li>
              </ul>
            </div>
            <div>
              <h3 className="text-sm font-semibold text-white uppercase tracking-wider">Legal</h3>
              <ul className="mt-4 space-y-2 text-sm">
                <li><Link to="/terms" className="hover:text-white">Terms of Service</Link></li>
                <li><Link to="/privacy" className="hover:text-white">Privacy Policy</Link></li>
                <li><Link to="/admin/login" className="hover:text-white opacity-50">Admin Login</Link></li>
              </ul>
            </div>
          </div>
          <div className="mt-12 border-t border-stone-800 pt-8 text-center text-xs">
            <p>&copy; {new Date().getFullYear()} HandyManJa. All rights reserved. Built for Jamaica.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
