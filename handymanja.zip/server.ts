import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { Resend } from "resend";
import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";

dotenv.config();

const isSupabaseConfigured = !!(process.env.VITE_SUPABASE_URL && process.env.SUPABASE_SERVICE_ROLE_KEY);
const resend = process.env.RESEND_API_KEY ? new Resend(process.env.RESEND_API_KEY) : null;
const supabase = isSupabaseConfigured 
  ? createClient(process.env.VITE_SUPABASE_URL!, process.env.SUPABASE_SERVICE_ROLE_KEY!)
  : null;

async function startServer() {
  const app = express();
  const PORT = 3000;

  if (!isSupabaseConfigured) {
    console.warn("⚠️ Supabase environment variables are missing. Running in DEMO MODE.");
  }

  app.use(express.json());

  // Health Check
  app.get("/api/health", (req, res) => {
    res.json({ ok: true, demo: !isSupabaseConfigured });
  });

  // POST /api/request
  app.post("/api/request", async (req, res) => {
    try {
      const data = req.body;
      const referenceId = `HMJ-${Math.random().toString(36).substring(2, 8).toUpperCase()}`;
      
      if (supabase) {
        const { error } = await supabase
          .from("service_requests")
          .insert([{ ...data, reference_id: referenceId, status: "New" }]);
        if (error) throw error;
      } else {
        console.log("[DEMO MODE] Service Request received:", { ...data, reference_id: referenceId });
      }

      // Send Email Notification
      if (resend) {
        await resend.emails.send({
          from: "HandyManJa <ops@handymanja.com>",
          to: "team@pytchmarketing.com",
          subject: `New Service Request: ${referenceId}`,
          text: `New request from ${data.name} for ${data.category} in ${data.parish}. Reference: ${referenceId}`,
        });
      }

      const whatsappLink = `https://wa.me/18760000000?text=${encodeURIComponent(
        `Hi HandyManJa, I'm following up on my request ${referenceId} for ${data.category} in ${data.parish}. Urgency: ${data.urgency}.`
      )}`;

      res.json({ referenceId, whatsappLink, demo: !isSupabaseConfigured });
    } catch (error: any) {
      console.error("Request Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // POST /api/join
  app.post("/api/join", async (req, res) => {
    try {
      const data = req.body;
      if (supabase) {
        const { error } = await supabase
          .from("workforce_applications")
          .insert([{ ...data, status: "New" }]);
        if (error) throw error;
      } else {
        console.log("[DEMO MODE] Workforce Application received:", data);
      }

      if (resend) {
        await resend.emails.send({
          from: "HandyManJa <ops@handymanja.com>",
          to: "team@pytchmarketing.com",
          subject: `New Workforce Application: ${data.full_name}`,
          text: `${data.full_name} applied for ${data.skills.join(", ")} in ${data.parish}.`,
        });
      }

      res.json({ success: true, demo: !isSupabaseConfigured });
    } catch (error: any) {
      console.error("Join Error:", error);
      res.status(500).json({ error: error.message });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
